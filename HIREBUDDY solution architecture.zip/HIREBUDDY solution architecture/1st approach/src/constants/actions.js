// Feed Actions
export const VOTE_UP = 'VOTE_UP';
export const VOTE_DOWN = 'VOTE_DOWN';
export const TOGGLE_FAVORITE = 'TOGGLE_FAVORITE';
export const TOGGLE_FILTER = 'TOGGLE_FILTER';
export const ADD_STORY = 'ADD_STORY';

// User Actions
export const LOGIN_USER = 'LOGIN_USER';
export const LOGOUT_USER = 'LOGOUT_USER';