var app = require('../../../../core/app'),
    validate = require('../../../../core/validation'),
    popup = require("../../../../core/components/popup/popup"),
    applicationDetails = require("../applicationDetails/applicationDetails");

module.exports = app.extend({
    template: 'personalDetails',
    init: function() {
        var self = this;
        var ajaxObj = {
            fileName: './personalDetails/testPersonalDetails.json',
            callback: (self.personalDetailscallback).bind(self)
        };
        this.makeAjaxRequest(ajaxObj);
    },
    personalDetailscallback: function(response) {
        this.data = JSON.parse(response);
        this.compileTemplate();
        var objValidate = new validate( /*{callback:this.checkvalidData, formName:'form-add-candidate'}*/ );
        objValidate.applyValidation(this.checkValidData.bind(this), 'form-add-candidate');
    },

    checkValidData: function() {
        var email = document.getElementById("email").value,
            i, len, flag, mailId;

        for (i = 0, len = this.data.length; i < len; i++) {
            if (this.data[i].email == email) {
                flag = true;
                mailId = this.data[i];
                console.log(mailId);
                break;
            } else {
                flag = false;
            }
        }
        if (flag) {
            new popup({ el: ".popup", type: mailId });
            document.querySelector(".popup").style.display = "block";
            document.querySelector(".popup").nextElementSibling.className = "cover";
        } else {
            document.getElementById("checkDuplicate").value = "Checked";
            var applicationDetailsObj = new applicationDetails({ el: "#applicationDetails" });
        }
    }
});