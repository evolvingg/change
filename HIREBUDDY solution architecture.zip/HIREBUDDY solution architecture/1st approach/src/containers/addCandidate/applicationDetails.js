var app = require('../../../../core/app'),
validate = require('../../../../core/validation'),
addShadowComp = require("../../../../core/components/shadowPanelist/shadowPanelist"), self;

module.exports = app.extend({
	template: 'applicationDetails',
	init: function() {
		var self = this;
		var ajaxObj = {
			fileName: '../../../../../src/modules/recruiter/addCandidate/applicationDetails/applicantTitle.json',
			callback: (self.mockFunction).bind(self)
		};
		this.makeAjaxRequest(ajaxObj);
	},

	mockFunction: function(response){
		self = this;
		self.data = JSON.parse(response);
		self.compileTemplate();
		self.attachHandlers();
		var addShadowObj = new addShadowComp({el: "compAddShadow"});
		self.datePicker();
	},

	attachHandlers: function(){
		var typeTest = document.getElementById("typeTest"),
		typePhone = document.getElementById("typePhone");
		typeTest.addEventListener("click",this.showTestType);
		typePhone.addEventListener("click",this.showPhoneType);
	},
	
	showTestType: function(){
		document.getElementsByClassName("test-type")[0].style.display = "block";
		document.getElementsByClassName("phone-type")[0].style.display = "none";
	},

	showPhoneType: function(){
		document.getElementsByClassName("test-type")[0].style.display = "none";
		document.getElementsByClassName("phone-type")[0].style.display = "block";
	},

	datePicker: function(){
		var picker = new Pikaday({
		field: document.getElementById('datepicker'),
		format: 'DD/MM/YYYY',
		});
	}

});
