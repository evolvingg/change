var personal_details = require('./personalDetails.js'),
    expect = chai.expect;


describe('personal_details',function(){
    it('checks for status',function(){
        var expected={email:'sumit@gmail.com',status:'rehire'},
                     {email:'priya@yahoo.com',status:'disqualified'}];
            
              
        var actual=z.getStatus();
        expect(actual).to.be.equal(expected);                
    
    });
});
