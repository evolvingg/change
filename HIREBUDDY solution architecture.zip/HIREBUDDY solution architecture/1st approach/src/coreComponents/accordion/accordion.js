var app = require('../../app');
module.exports = app.extend({
    template: 'accordion',
    init: function() {
        if (this.type === "addDelete") {
            var ajaxObj = {
                fileName: '/src/core/components/accordion/accordion.json',
                callback: (this.addDeleteCallback).bind(this)
            };
        } else {
            var ajaxObj = {
                fileName: '/src/core/components/accordion/interviewFeedback.json',
                callback: (this.aiInterviewCallback).bind(this)
            };
        }
        this.makeAjaxRequest(ajaxObj);
    },
    /**
     * [Callback function if type is addDelete]
     * @param {json object} response [json data]
     */
    addDeleteCallback: function(response) {
        var self = this,
            questionField = document.getElementsByClassName("question-field"),
            i, n;
        self.data = JSON.parse(response);
        self.compileTemplate();
        self.addDeleteQuestion();
        for (i = 0, n = questionField.length; i < n; i++) {
            questionField[i].addEventListener('click', function(e) {
                self.toggleClass(this.nextElementSibling, "show");
                self.toggleClass(this.querySelector("i"), "hide-icon");
            });
        }

    },
    /**
     * [Callback function if type is aiInterview]
     * @param {json object} response [json data]
     */
    aiInterviewCallback: function(response) {
        var self = this,
            questionField = document.getElementsByClassName("question-field"),
            i, n;
        self.data = JSON.parse(response);
        self.compileTemplate();
        for (i = 0, n = questionField.length; i < n; i++) {
            questionField[i].addEventListener('click', function(e) {
                self.toggleClass(this.nextElementSibling, "show");
                self.toggleClass(this.querySelector("i"), "hide-icon");
                self.aiInterview(this);

            });
        }
    },
    /**
     * [function to toggle class]
     * @param  {object} object           [object on which you need to toggle class]
     * @param  {string} classToBeToggled [class name]
     * @return {}                        [nothing]
     */
    toggleClass: function(object, classToBeToggled) {
        if (object.className.indexOf(classToBeToggled) != -1) {
            var classesLeft, classesRight;
            classesLeft = object.className.split(classToBeToggled)[0].trim();
            classesRight = object.className.split(classToBeToggled)[1].trim();
            object.className = classesLeft + " " + classesRight;
        } else {
            object.className = object.className + " " + classToBeToggled;
        }
    },
    /**
     * [function to instantiate add delete module and appending data]
     */
    addDeleteQuestion: function(clickedNode) {
        var addDelete = require("../../../modules/panelist/newInterviewRound/addDelete/addDelete");
        var quesTopics = document.querySelectorAll('#questionParent li');
        for (var i = 1; i <= quesTopics.length; i++) {
            new addDelete({ el: '#questionParent li:nth-child(' + i + ')>.question-data:nth-child(2)' });   
        }
    },
    /**
     * [function to instantiate interview feedback module and appending data]
     * @param  {object} clickedNode [object on which clicked]
     * @return {}                   [nothing]
     */
    aiInterview: function(clickedNode) {
        var index = clickedNode.querySelector("span").innerText,
            aiInterview = require("../../../modules/panelist/aiInterview/interviewFeedback/interviewFeedback"),
            quesTopics = document.querySelectorAll('#parent li'),
            listItem = document.querySelectorAll('.ques-response'),
            parentNode = clickedNode.parentNode,
            liIndex = 0,
            i, n;
        // finding the corresponding question field and appending the data in it
        for (i = 0, n = listItem.length; i < n; i++) {
            if (listItem[i] === parentNode)
                liIndex = i + 1;
        }
        if(document.querySelector('#parent li:nth-child(' + liIndex + ')>.question-data:nth-child(2)').innerHTML == ""){
            new aiInterview({ el: '#parent li:nth-child(' + liIndex + ')>.question-data:nth-child(2)', type: index });
        }
    }
});