const feed = [
  {
    "posted": "2 months ago",
    "votes": 62,
    "comments": 66,
    "designation": "writer",
    "name": {
      "last": "Davenport",
      "first": "Marguerite"
    },
    "domain": "mazuda.com",
    "title": "exercitation elit id amet anim dolore elit Lorem irure qui veniam aliqua",
    "isStarred": true,
    "_id": "d3d042ab-a5c4-4a2b-84aa-7e67496a79b4"
  },
  {
    "posted": "6 months ago",
    "votes": 10,
    "comments": 25,
    "designation": "manager",
    "name": {
      "last": "Washington",
      "first": "Sue"
    },
    "domain": "savvy.com",
    "title": "velit velit sunt cupidatat esse incididunt irure proident reprehenderit minim ex excepteur",
    "isStarred": true,
    "_id": "01a37ec0-7dba-4945-b750-b149dfcd7a93"
  },
  {
    "posted": "5 months ago",
    "votes": 16,
    "comments": 75,
    "designation": "developer",
    "name": {
      "last": "Valdez",
      "first": "Rodriquez"
    },
    "domain": "frenex.com",
    "title": "in culpa labore tempor cillum ullamco qui ex nisi fugiat proident non",
    "isStarred": true,
    "_id": "6f0bd65a-c104-448b-80fc-cd0d71d53350"
  },
  {
    "posted": "8 months ago",
    "votes": 32,
    "comments": 32,
    "designation": "manager",
    "name": {
      "last": "Merritt",
      "first": "Lorene"
    },
    "domain": "konnect.com",
    "title": "anim fugiat irure amet duis duis fugiat aliqua laborum cillum culpa occaecat",
    "isStarred": false,
    "_id": "06540e6d-d295-47ea-aa24-b0e766b4f00a"
  },
  {
    "posted": "2 months ago",
    "votes": 53,
    "comments": 70,
    "designation": "designer",
    "name": {
      "last": "Pace",
      "first": "Parker"
    },
    "domain": "gink.com",
    "title": "aliqua ullamco labore culpa labore proident anim qui laborum reprehenderit cillum ea",
    "isStarred": false,
    "_id": "d4c712de-c8ff-46d2-86a3-417b9f6a6d72"
  },
  {
    "posted": "a month ago",
    "votes": 69,
    "comments": 47,
    "designation": "developer",
    "name": {
      "last": "Rice",
      "first": "Rosella"
    },
    "domain": "eweville.com",
    "title": "nulla in minim occaecat ullamco cupidatat cillum cupidatat magna veniam veniam exercitation",
    "isStarred": true,
    "_id": "f27b0551-d0fb-4178-b974-7f05640133e5"
  },
  {
    "posted": "10 months ago",
    "votes": 12,
    "comments": 3,
    "designation": "designer",
    "name": {
      "last": "Schmidt",
      "first": "Harris"
    },
    "domain": "reversus.com",
    "title": "aute Lorem aliqua ipsum veniam nulla adipisicing voluptate anim labore ipsum qui",
    "isStarred": false,
    "_id": "04147c48-7243-4531-a100-3611c080cc3a"
  }
];

export default feed;