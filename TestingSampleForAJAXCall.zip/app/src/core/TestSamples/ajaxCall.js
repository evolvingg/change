module.exports = {
        testCall: function(msg) {
            // console.log('make ajax call : ' + msg);
            return msg;
        },
        makeAjaxRequest: function(ajaxObj) {
             // console.log("Making AJAX CALL : " + ajaxObj.type);
             // console.log("Ajax Object fileName: " + ajaxObj.fileName);
             // console.log("Ajax Object callback: " + ajaxObj.callback);

            var methodName = ajaxObj.type || "GET",
                fileName = ajaxObj.fileName,
                postData = ajaxObj.data || "",
                successCallback = ajaxObj.callback;
            var xhttp,
                contentType = ajaxObj.content || 'application/x-www-form-urlencoded';

            var res,
                self = this;

            if (window.XMLHttpRequest) {
                xhttp = new XMLHttpRequest();
                // console.log("xhttp : "+xhttp);
            } else {
                // code for IE6, IE5
                xhttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            xhttp.onreadystatechange = function() {
                // console.log("On ready state ::"+typeof xhttp);
                
                if (this.readyState != 4) {
                    // console.log("ready state 4 ::"+this.status);
                    if (this.status == 200) {
                        // console.log("ready state 200 "+this.responseText);
                        res = this.responseText;
                        // console.log("Response Text 1: "+res);
                        if (successCallback == null) return res;
                        else successCallback(res);
                    } else {
                        console.log("network error");
                    }
                }
            }
            if (methodName == 'GET') {
                // console.log("GET reached :"+methodName);
                // console.log("GET reached :"+fileName);
                // console.log("xhttp : "+xhttp);
                xhttp.open(methodName, fileName, true);
                xhttp.send();
            } else {
                // console.log("PUT reached :"+postData);
                //  console.log("PUT reached :"+fileName);
                //  console.log("PUT reached : "+contentType);
                xhttp.open(methodName, fileName, true);
                xhttp.setRequestHeader('Content-type', contentType);
                xhttp.send(postData);
            }
            return res;
        },


    mockedCallBack: function(res) {

        //console.log("mockedCallBack called : " + res);

        return JSON.parse(res)[0]['onProcess'];

    }
}
