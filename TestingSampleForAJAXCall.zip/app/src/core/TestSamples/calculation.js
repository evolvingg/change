module.exports = {
	Add: function(v1,v2) {
        console.log("Add : "+(v1 + v2));
		return v1 + v2;
	},
    Substract: function(v1,v2) {
        console.log("Difference : "+(v1 - v2));
		return v1 - v2;
	},
    Square : function(val){
        var res;
        res = val * val; 
        console.log("Square : "+res);
        return res;
    },
    getSalary:function(_empId){
        var basic = 10000;
        var hra = 2000;
        var bonus = 1000;
        var total;
        var res;
        
        if(_empId === 1){
            total = basic + hra + bonus;
            res = "Emp " + _empId + " salary is " + total;
        }else {
            res = "This is invalid emp id " + _empId;
        }
        console.log(res);
        return res;
    }   
}