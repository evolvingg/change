module.exports = {
    msg:"Hello",
    DisplayName: function(nm){

    	console.log(this.msg + " " + nm)
        return this.msg + " " + nm;
    }
}