var base = require('./base');
module.exports = Class.extend({
    data: '',
    initialize: function(options) {
        for (var i in options) {
            this[i] = options[i];
        }


        if (this.init) {
            this.init();
        }
    },
    compileTemplate: function() {
        document.getElementById(this.el).innerHTML = (MyApp.templates[this.template])(this.data);
    },

    makeAjaxRequest: function(ajaxObj) {
        var methodName = ajaxObj.type || "GET",
            fileName = ajaxObj.fileName,
            postData = ajaxObj.data || "",
            successCallback = ajaxObj.callback;
        var xhttp,
            contentType = ajaxObj.content || 'application/x-www-form-urlencoded';
        var loader = document.getElementById('loader');
        var res,
            self = this;

        if (window.XMLHttpRequest) {
            xhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xhttp = new ActiveXObject('Microsoft.XMLHTTP');
        }
        xhttp.onreadystatechange = function() {
            if (this.readyState != 4) {
                if (loader)
                    loader.className = "loader";
            } else if (xhttp.status == 200) {
                if (loader)
                    loader.className = '';
                res = this.responseText;
                if (successCallback === null) return res;
                else successCallback(res);
            } else {
                //self.popup(objPopup);
                console.log("network error");
            }
        };
        if (methodName == 'GET') {
            xhttp.open(methodName, fileName, true);
            xhttp.send();
        } else {
            xhttp.open(methodName, fileName, true);
            xhttp.setRequestHeader('Content-type', contentType);
            xhttp.send(postData);
        }
        return res;
    }
})
