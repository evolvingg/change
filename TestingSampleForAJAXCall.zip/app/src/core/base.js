(function () {
    var initializing = false,
        superPattern =
            /xyz/.test(function () {
                xyz;
            }) ? /\b_super\b/ : /.*/;

    this.Class = function () {
    };
    Class.extend = function (properties) {
        var _super = this.prototype;
        initializing = true;
        var proto = new this();
        initializing = false;
        for (var name in properties) {
            proto[name] = typeof properties[name] == "function" &&
                typeof _super[name] == "function" &&
                superPattern.test(properties[name]) ?
                (function (name, fn) {
                    return function () {
                        var tmp = this._super;
                        this._super = _super[name];
                        var ret = fn.apply(this, arguments);
                        this._super = tmp;
                        return ret;
                    };
                })(name, properties[name]) :
                properties[name];
        }
        function Class() {
            // All construction is actually done in the init method
            if (!initializing && this.initialize)
                this.initialize.apply(this, arguments);
        }

        Class.prototype = proto;
        Class.constructor = Class;
        Class.extend = arguments.callee;
        return Class;
    };
})();


if(navigator.appName == 'Microsoft Internet Explorer') { 
    var placeholderPolyfill = function(){
        inpArr = document.querySelectorAll('input[type=text]');
        for(i = 0;i<inpArr.length;i++){
            inp = inpArr[i];
            inp.value = inp.getAttribute('placeholder');
            inp.setAttribute("data-placeholder", "true");

            inp.addEventListener('blur',function(){
                if(this.value===''){
                    this.setAttribute('data-placeholder',true);
                    this.value = this.getAttribute('placeholder');
                }
            });
            inp.addEventListener('focus',function(){
                    if(this.getAttribute('data-placeholder')=='true'){
                        this.value ='';
                        this.setAttribute('data-placeholder','false');
                    }
            });

        }
    };

    placeholderPolyfill();
};