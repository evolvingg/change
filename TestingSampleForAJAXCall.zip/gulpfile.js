var handlebars = require('gulp-handlebars');
var wrap = require('gulp-wrap');
var declare = require('gulp-declare');
var concat = require('gulp-concat');
var gulp = require('gulp');
var sass=require('gulp-sass');
var browserify = require('gulp-browserify');

var Server = require('karma').Server;

/*Task to convert Sass to Css*/
gulp.task('sass', function () {
  return gulp.src('./app/src/**/*.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(concat('style.css'))
    .pipe(gulp.dest('./app/assets/css'));
});

/*Watch for changes in sass*/
gulp.task('sass:watch', function () {
    gulp.watch('./app/**.scss', ['sass']);
});

gulp.task('default',function(){
   console.log('Specify a task');
});

gulp.task('serve',['templates','sass','sass:watch'],function(){
    require('./server.js');
});

/*This task will create bundle.js using browserify*/
gulp.task('bundle', function(){
  gulp.src('app/src/modules/**/*.js')
    .pipe(browserify())
    .pipe(concat('bundle.js'))
    .pipe(gulp.dest('app/assets/js/'));
});


gulp.task("bundle:watch", function() {
    // calls "build-js" whenever anything changes
    gulp.watch("app/src/modules/**/*.js", ["bundle"]);
});

gulp.task('templates', function(){
  gulp.src('app/src/**/*.hbs')
    .pipe(handlebars())
    .pipe(wrap('Handlebars.template(<%= contents %>)'))
    .pipe(declare({
      namespace: 'MyApp.templates',
      noRedeclare: true, // Avoid duplicate declarations 
    }))
    .pipe(concat('templates.js'))
    .pipe(gulp.dest('app/assets/js/'));
});

/* Task for pre-commit hook */
gulp.task('preCommit', ['lint', 'tdd']);

gulp.task('lint', function () {
    return gulp.src(['./app/**/*.js', '!./app/**/^test'])
            .pipe(jslint({
                predef: [ 'a_global' ],
                global: [ 'a_global' ]
            }))
             .pipe(jslint.reporter( 'default' ));
           
});
/**
 * Run test once and exit
 */
gulp.task('test', function(done) {
    new Server({
        configFile: __dirname + '/karma.config',
        singleRun: true
    }, done).start();
});

/**
 * Watch for file changes and re-run tests on each change
 */
gulp.task('tdd', function(done) {
    new Server({
        configFile: __dirname + '/karma.config'
    }, done).start();
});