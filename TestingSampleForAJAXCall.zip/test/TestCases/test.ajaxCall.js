var ajaxCall = require('../../app/src/core/TestSamples/ajaxCall');
var expect = chai.expect;


describe("Testing the AJAX call", function() {

    var msg = 5;

    /*Test case 1 : to call testCall method of ajaxCall*/

    it("should return 5 ", function() {

        expect(ajaxCall.testCall(msg)).to.equal(5);
    });

    /*Test case 2 : to call testCall method of ajaxCall*/

    /*Setting up a fake server via sinon */

    beforeEach(function() {
        this.server = sinon.fakeServer.create();
    });

    /*Refreshing the server after each test run*/

    afterEach(function() {
        this.server.restore();
    });


    /*Actually test case */

    it("Should match the response from server with GET method", function(done) {

        //Dummy data in JSON
        var data = '[{"onProcess": 7, "selected": 3, "disQualified": 4}]'; //Dummy data from JSON
        var dataParsed = JSON.parse(data)[0]; //Just parsing the data that we are sending to the call back function so that we can match the response

        //Expected dummy response
        var response = [200, { "Content-Type": "application/json" }, data];

        // Parsing the received dummy data, to compare it with the data send to callback method 'mockCallback' method
        var responseParsed = JSON.parse(response[2])[0];

        //Creating a spy method using sinonjs, to simulate 'mockedCallBack' method as in ajaxCall class
        var spy = sinon.spy(ajaxCall, "mockedCallBack");

        //This is the dummy object that we will pass to the 'makAjaxRequest' method to get a response
        var ajaxObj = {
            type: 'GET',
            fileName: '/candidates.json',
            data: '',
            callback: spy
        };

        this.server.respondWith('GET', '/candidates.json', response); //Server response
        // console.log("Response : " + response)

        ajaxCall.makeAjaxRequest(ajaxObj); //Calling the function from the ajaxCall.js;

        // console.log("My JSON DATA :=>>>>>>>>>>>    " + ajaxObj.callback(data));

        expect(ajaxObj.callback(data)).to.equal(responseParsed['onProcess']); //To pass the test Checking the desired values and equating them

        this.server.respond();

        done();
    });

    it("should return onProcess as 7", function() {

        //Passing an object and returing onProcess data as 7
        var data = '[{"onProcess": 7, "selected": 3, "disQualified": 4}]'; //Dummy data from JSON

        expect(ajaxCall.mockedCallBack(data)).to.equal(7);

    });


});

// describe("Object matching test case via sinon", function() {

//     it("should match the object", function() {

//         var book = {
//             pages: 42,
//             author: "cjno"
//         };
//         var spy = sinon.spy();

//         spy(book);

//         sinon.assert.calledWith(spy, sinon.match({ author: "cjnoV" }));//Fails
//         sinon.assert.calledWith(spy, sinon.match.has("pages", 42));//Passes
//     });
// });
