// var calculation = require('../../app/src/core/SampleJs/calculation');
// var expect = chai.expect;
// // console.log("Calculation test");
// describe("Calculation", function() {
// 	it("Addition", function() {
// 		expect(calculation.Add(2,3)).to.equal(5);
// 	});
    
//     it("Substraction", function() {
// 		expect(calculation.Substract(10,3)).to.equal(7);
// 	});
    
//     it("Square", function() {
// 		expect(calculation.Square(4)).to.equal(16);
// 	});
// });