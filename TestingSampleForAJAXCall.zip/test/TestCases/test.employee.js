// var emp = require('../../app/src/core/TestSamples/employee');
// //importing other module
// var calc = require('../../app/src/core/TestSamples/calculation');
// var expect = chai.expect;

// describe("Employees", function() {
// 	it("Welcome", function() {
// 		expect(emp.DisplayName('Buddy')).to.equal('Hello Buddy');
// 	});
    
//     //calling method of calculation.js class
//     it("EmpSalary", function() {
// 		expect(calc.getSalary(1)).to.equal('Emp 1 salary is 13000');
//         expect(calc.getSalary(2)).to.equal('This is invalid emp id 2');
// 	});
// });