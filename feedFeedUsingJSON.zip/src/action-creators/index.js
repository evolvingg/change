import fetch from 'isomorphic-fetch'
import * as actions from '../constants/actions';
import * as constants from '../constants/constants';

export const upVote = id => ({
  type: actions.VOTE_UP,
  id
});

export const downVote = id => ({
    type: actions.VOTE_DOWN,
    id
});

export const toggleFavorite = id => ({
  type: actions.TOGGLE_FAVORITE,
  id
});

export const toggleFilter = filter => ({
  type: actions.TOGGLE_FILTER,
  filter
});

export const loginUser = email => ({
  type: actions.LOGIN_USER,
  email
});

export const logoutUser = () => ({
  type: actions.LOGOUT_USER
});

export const loadJsonSuccess = feed => ({
  type: actions.LOAD_JSON_SUCCESS, 
	feed
});


//this function load json using fetch
export function loadData(){
	return function(dispatch){
		return fetch(constants.FEED_DATA)
			.then(function(res){
				return res.json();
			})
			.then(function(json){
				return dispatch(loadJsonSuccess(json));
			});
	}
}