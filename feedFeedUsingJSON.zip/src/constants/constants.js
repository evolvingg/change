export const FEED_DATA = 'data/feedData.json';
