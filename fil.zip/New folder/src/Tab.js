import React from 'react';
export default class Tab extends React.Component{
	constructor(props){
		super(props);
		this.onStar = this.onStar.bind(this);
		this.removeStar = this.removeStar.bind(this);
	}
	render()
}