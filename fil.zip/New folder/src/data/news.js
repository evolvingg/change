export default [
  {
    id:1,
    name: 'Winner Skeleton',
    data: 23
  },
  {
    id:2,
    name: 'Citizen Men',
    data:20
   
  },
    {
    id: 4,
    name: 'Citizen Analog',
    data:12
    },
  {
    id: 6,
    name: 'Armani Exchange',
    data:5
      },
  {
    id: 5,
    name: 'Citizen Unisex',
    data:16   
  },
  {
    id: 3,
    name: 'Relish Analog',
    data:40
  }
]
