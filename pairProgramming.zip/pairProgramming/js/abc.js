

		var name1 = function(name) {
			if(name === 'abc') {
			return 'Hi '+name;
		} else {
			return 'Hello '+name;
		}
		}

var unique = require('uniq');

var data = [1, 2, 2, 3, 4, 5, 5, 5, 6];

console.log(unique(data));


module.exports = {

	displayName: function(name) {


		return name1(name);

		
	}
}