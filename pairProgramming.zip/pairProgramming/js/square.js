var abc = require('./abc');

module.exports = {
	square: function(value) {
		return (value * value);
	}
}