module.exports = function(config) {
    config.set({
        basePath: '',
        autoWatch: true,
        frameworks: ['mocha', 'chai', 'commonjs'],
        files: [
            'js/**/*.js',
            'test/*.js'
        ],
        plugins: [
            'karma-coverage',
            'karma-mocha',
            'karma-chai',
            'karma-commonjs',
            'karma-phantomjs-launcher',
            'karma-commonjs-require'
        ],

        browsers: ['PhantomJS'], // , 'Firefox'],

        reporters: ['progress', 'coverage'],
        preprocessors: { 'js/**/*.js': ['coverage', 'commonjs'],
        'test/**/*.js': ['commonjs'] },

        singleRun: true,

        coverageReporter: {
            dir: 'coverage/',
            reporters: [
                { type: 'html', subdir: 'html' }
            ]
        }
    });
};
