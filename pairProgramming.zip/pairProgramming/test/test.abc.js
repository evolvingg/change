var expect = chai.expect;
var displayName = require('../js/abc');
describe("Abc", function() {

	it("displayName:", function() {
		expect(displayName.displayName('Sumit')).to.equal('Hello Sumit');
		expect(displayName.displayName('abc')).to.equal('Hi abc');
	});



});