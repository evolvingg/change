var square = require('../js/square');
var expect = chai.expect;

describe("Component", function() {

	it("Square", function() {
		expect(square.square(2)).to.equal(4);
	});




});